# Router Study Project

- React Router 학습을 위한 프로젝트

## 프로젝트 목적

- React Router 기능의 이해
- Bootstrap 활용의 이해
- CORS의 이해

## 프로젝트 시나리오

- [피그마 주소](http://)
- [노션 주소](http://)

## 프로젝트 참여 인원

- 손용수

## 프로젝트 일정

- 2023-06-12 ~ 2023-06-14

## 활용 기술

- React
- React Router
- Bootstrap
- Youtube Library
- SCSS
