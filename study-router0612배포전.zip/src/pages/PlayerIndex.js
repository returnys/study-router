import React from "react";

const PlayerIndex = () => {
  return (
    <div>
      <hr />
      <h3>현재 재생중인 곡이 없습니다.</h3>
    </div>
  );
};

export default PlayerIndex;
